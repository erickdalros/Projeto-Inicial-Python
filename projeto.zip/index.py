import random
import json
import os
def gerarSenha():
    print("Gerando sua senha: ")
    senha = random.randint(111111, 999999)
    print("Sua senha gerada é: ", senha)

def calculadora():
    valorUm = float(input("Digite o valor 1: "))
    opera = float(input("Selecione a opção que deseja:\n[1] = +\n[2] = -\n[3] = *\n[4] = / \n[5] = %\nResultado: "))
    valorDois = float(input("Digite o valor dois: "))

    if opera == 1:
        resultUm = valorUm + valorDois
        print("Valor Calculado: ", resultUm)
    if opera == 2:
        resultDois = valorUm - valorDois
        print("Valor Calculado: ", resultDois)
    if opera == 3:
        resultTres = valorUm * valorDois
        print("Valor Calulado: ", resultTres)
    if opera == 4:
        resultQuatro = valorUm / valorDois
        print("Valor Calculado: ", resultQuatro)
    


def jogoForca():
    listaWord = [
    'casa', 'amarelo', 'cimento', 'garrafa', 'janela', 'parede', 'tijolo', 'construção', 'porta', 'telhado',
    'mesa', 'cadeira', 'sofa', 'armario', 'espelho', 'computador', 'teclado', 'mouse', 'telefone', 'celular',
    'televisao', 'controle', 'video', 'musica', 'guitarra', 'violino', 'piano', 'bateria', 'microfone', 'radio',
    'internet', 'rede', 'cabo', 'energia', 'eletricidade', 'lampada', 'tomada', 'bateria', 'relogio', 'calendario',
    'agenda', 'caderno', 'caneta', 'lapis', 'borracha', 'livro', 'folha', 'papel', 'quadro', 'tela', 'pintura',
    'cor', 'azul', 'verde', 'vermelho', 'laranja', 'rosa', 'roxo', 'preto', 'branco', 'cinza', 'dourado',
    'prata', 'bronze', 'ferro', 'aço', 'madeira', 'plastico', 'vidro', 'ceramica', 'pedra', 'marmore',
    'areia', 'terra', 'grama', 'flor', 'arvore', 'folha', 'fruta', 'banana', 'maca', 'uva', 'laranja',
    'morango', 'melancia', 'abacaxi', 'coco', 'limão', 'pera', 'pessego', 'cereja', 'manga', 'abacate',
    'kiwi', 'ameixa', 'tomate', 'cenoura', 'batata', 'cebola', 'alho', 'pimentão', 'salada', 'verdura'
    ]
    gerar = random.randint(0, 3)
    escolhaWord = listaWord[gerar]
    tentativas = 10  

    while tentativas > 0:
        escolha = input("Digite uma letra ou chute a palavra: ")
        
        if escolha == escolhaWord:
            print("Acertou a palavra inteira!!")
            break
        elif escolha in escolhaWord:
            print(f"A letra '{escolha}' está na palavra!")
        else:
            print("Errou!!")
            tentativas -= 1
            print(f"Você tem {tentativas} tentativas restantes.")
    if tentativas == 0:
        print(f"Suas tentativas acabaram! A palavra era '{escolhaWord}'.")


def agendaContato():
    dados_json = "dados.json"

    def carregarContatos():
        if os.path.exists(dados_json):
            with open(dados_json, "r") as file:
                return json.load(file)
        return [] 

    def salvaDados(dados):
        with open(dados_json, "w") as file:
            json.dump(dados, file, indent=4)

    def adicionar_usuario():
        nome = input("Digite o Nome do Contato: ")
        telefone = input("Digite o Telefone do Contato: ")

        dados = carregarContatos()
        dados.append({"nome": nome, "telefone": telefone})
        salvaDados(dados)
        print("Usuário Adicionado com sucesso!!")

    def listarContatos():
        dados = carregarContatos()
        if not dados:
            print("Nenhum usuário cadastrado.")
        else:
            for i, usuario in enumerate(dados, 1):
                print(f"{i}. Nome: {usuario['nome']}, Telefone: {usuario['telefone']}")

    def buscarUser():
        nomeBuscar = input("Digite o nome ou telefone para buscar: ")
        dados = carregarContatos()

        encontrados = [u for u in dados if u["nome"].lower() == nomeBuscar.lower()]

        if encontrados:
            for usuario in encontrados:
                print(f"Nome: {usuario['nome']}, Telefone: {usuario['telefone']}")
        else:  
            print("Usuário não localizado.")

    def removerUser():
        nomeRemover = input("Digite o nome que deseja remover: ")
        dados = carregarContatos()

        novos_dados = [u for u in dados if u["nome"].lower() != nomeRemover.lower()]

        if len(novos_dados) < len(dados):
            salvaDados(novos_dados)
            print("Usuário removido com sucesso!")
        else:
            print("Usuário não encontrado.")

    while True:
        print("\n===== MENU =====")
        print("[1] - Adicionar Contato")
        print("[2] - Remover Contato")
        print("[3] - Ver Lista de Contatos")
        print("[4] - Buscar Contato específico")
        print("[5] - Sair")

        try:
            opc = int(input("Escolha: "))

            if opc == 1:
                adicionar_usuario()
            elif opc == 2:
                removerUser()
            elif opc == 3:
                listarContatos()
            elif opc == 4:
                buscarUser()
            elif opc == 5:
                print("Saindo do programa...")
                break
            else:
                print("Opção inválida. Escolha um número entre 1 e 5.")
        except ValueError:
            print("Entrada inválida! Digite um número válido.")






def menu():
    print("\n" + "="*40)
    print("📌  SELECIONE UMA OPÇÃO  📌".center(40))
    print("="*40)
    print("  [1] 🔐  Gerador de Senha")
    print("  [2] 🧮  Calculadora")
    print("  [3] 🎮  Jogo da Forca")
    print("  [4] 📒  Agenda de Contatos")
    print("  [5] ❌  Sair")
    print("="*40)    
    
    opc = int(input("Escolha: "))

    if opc == 1:
        print("\n🔐 Gerador de Senha selecionado...")
        gerarSenha()
    if opc == 2:
        print("\n🧮 Calculadora selecionada...")
        calculadora()
    if opc == 3:
        print("\n🎮 Jogo da Forca selecionado...")
        jogoForca()
    if opc == 4:
        print("\n📒 Agenda de Contatos selecionada...")
        agendaContato()
menu()